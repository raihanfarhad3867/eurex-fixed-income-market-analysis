# Eurex Fixed-Income Futures Activity & Product Opportunity Monitor

Independent portfolio project by Raihan Farhad Sakil.

## The simple question
If I were supporting a Eurex fixed-income product team, how would I use public trading statistics to understand **where activity is concentrated, what the futures roll does to the numbers, and where a real product-growth problem might exist?**

This project deliberately moves beyond "I made a chart." It connects market data to a product-development decision.

## What I analysed
- Euro-Schatz Futures (FGBS) — short German government-bond exposure.
- Euro-Bobl Futures (FGBM) — medium German exposure.
- Euro-Bund Futures (FGBL) — long German benchmark exposure.
- Euro-Buxl (FGBX), Euro-BTP (FBTP), Euro-OAT (FOAT), Short-Term BTP (FBTS) as adjacent benchmarks.
- Euro-EU Bond Futures (FBEU) as a current **new-product adoption / liquidity formation** case.

## Evidence policy
- Jan–Jul 2026 figures are official Eurex Monthly Statistics.
- August is **derived**, not guessed: Sep 4 official YTD total minus Jan–Jul official totals minus Sep month-to-date volume.
- Sep 4 product-level volume and open interest come from an official Eurex Daily Statistics CSV.
- No claim is made that volume/open interest alone fully measure liquidity.

## Main findings
1. **German benchmark activity is deep.** FGBS/FGBM/FGBL together traded ~553.7m contracts Jan–Aug 2026, around 3.28m/day in aggregate.
2. **Bund is the activity anchor.** FGBL contributed ~39.3% of German three-product volume; FGBM 31.3%; FGBS 29.4%.
3. **Roll months change the picture.** March/June average monthly volume was about 118% above non-roll months for FGBS, 61% for FGBM and 59% for FGBL. March also coincided with unusually high market volatility, so roll is not the only explanation.
4. **Bund dominates the selected 10Y sovereign comparison.** FGBL represented ~65% of Jan–Aug volume across FGBL/FBTP/FOAT.
5. **FBEU is the more interesting product-management case.** On 4 Sep 2026 it showed 13,291 YTD contracts and 107 previous-day OI. Eurex also amended its liquidity-provider program effective Sep/Oct 2026. That makes the question "how do we build sustainable adoption?" more useful than proposing another new contract immediately.

## Charts
![German monthly volume](figures/01_german_monthly_volume.png)

![Average daily volume](figures/02_german_adv.png)

![10Y sovereign comparison](figures/03_10y_sovereign_comparison.png)

## Technical workflow
```text
Official Eurex monthly reports
          +
Official Sep-4 daily CSV
          ↓
Python parser + validation
          ↓
Jan-Aug master dataset
          ↓
ADV / MoM / roll-month / market-share metrics
          ↓
Charts + management memo
          ↓
Product-growth recommendation
```

## Run locally
```bash
pip install -r requirements.txt
python scripts/build_project.py
pytest -q
```

## Why this project fits a fixed-income analysis role
It demonstrates a workflow similar to junior exchange/product analytics: collect market data, validate it, interpret futures-specific effects, compare products, identify a growth problem, and turn analysis into a management recommendation.

## Important limitation
This is a public-data portfolio analysis, not an internal Eurex liquidity study. A production analysis should add bid/ask spreads, depth, trade-size distribution, client/account segmentation, market-maker quoting performance, TES/block data, execution costs and Bloomberg/internal market data where permitted.

See `reports/management_memo.md`, `docs/methodology.md` and `docs/concepts_for_interview.md`.
