from pathlib import Path
import pandas as pd
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from src.eurex_parser import parse_daily_statistics_csv

def test_sep04_parser():
    x=parse_daily_statistics_csv(ROOT/'data/raw/dailystat_20260904.csv')
    bund=x[x.product_code.eq('FGBL')].iloc[0]
    assert int(bund.daily_volume)==2026366
    assert int(bund.open_interest_prev_day)==2106126

def test_fbeu_snapshot():
    x=parse_daily_statistics_csv(ROOT/'data/raw/dailystat_20260904.csv')
    eu=x[x.product_code.eq('FBEU')].iloc[0]
    assert int(eu.year_to_date_volume)==13291
    assert int(eu.open_interest_prev_day)==107

def test_august_derivation_identity():
    raw=pd.read_csv(ROOT/'data/raw/monthly_official_extract.csv')
    x=parse_daily_statistics_csv(ROOT/'data/raw/dailystat_20260904.csv')
    bund=x[x.product_code.eq('FGBL')].iloc[0]
    jan_jul=raw[raw.product_code.eq('FGBL')].monthly_volume.sum()
    aug=int(bund.year_to_date_volume-jan_jul-bund.month_to_date_volume)
    assert aug==21511028
