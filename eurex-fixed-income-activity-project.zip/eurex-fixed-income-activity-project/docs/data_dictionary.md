# Data dictionary

## `monthly_volume_2026_jan_aug.csv`
- `month`, `year`: observation period.
- `trading_days`: Eurex trading days used for ADV.
- `product_code`: Eurex product ID.
- `product_name`: product label.
- `monthly_volume`: traded contracts during the month.
- `adv`: monthly volume / trading days.
- `roll_month`: True for March/June/September/December quarterly expiry months.
- `mom_change_pct`: month-on-month change in monthly volume.
- `source_type`, `source_url`, `notes`: evidence trail.

## `sep04_snapshot.csv`
Parsed from the official Eurex Daily Statistics CSV for 4 September 2026.
- `daily_volume`: traded contracts on 4 Sep.
- `month_to_date_volume`: Sep volume through 4 Sep.
- `year_to_date_volume`: 2026 volume through 4 Sep.
- `avg_daily_volume_month`: Sep MTD daily average.
- `avg_daily_volume_year`: YTD daily average.
- `open_interest_prev_day`: open interest from the previous trading day, exactly as labeled by Eurex.
