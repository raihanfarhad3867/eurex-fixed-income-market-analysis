from __future__ import annotations
from pathlib import Path
import sys
import pandas as pd
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.eurex_parser import parse_daily_statistics_csv
from src.analysis import add_metrics, german_curve_summary, ytd_summary

raw_monthly = pd.read_csv(ROOT / "data/raw/monthly_official_extract.csv")
sep = parse_daily_statistics_csv(ROOT / "data/raw/dailystat_20260904.csv")

# Reconstruct August from the Sep 4 official daily report:
# Aug = YTD at Sep 4 - Jan..Jul official monthly totals - Sep month-to-date at Sep 4.
aug_days = 21
aug_rows=[]
for code in ["FGBS","FGBM","FGBL","FGBX","FBTP","FOAT","FBTS"]:
    s = sep.loc[sep.product_code.eq(code)].iloc[0]
    jan_jul = raw_monthly.loc[raw_monthly.product_code.eq(code), "monthly_volume"].sum()
    aug = int(s.year_to_date_volume - jan_jul - s.month_to_date_volume)
    aug_rows.append({
        "month":"Aug", "year":2026, "trading_days":aug_days, "product_code":code,
        "product_name":s.product_name, "monthly_volume":aug,
        "source_type":"Derived from official Eurex Daily Statistics 2026-09-04",
        "source_url":"https://www.eurex.com/ex-en/data/statistics/trading-statistics",
        "notes":"Aug = Sep4 YTD - Jan-Jul official monthly totals - Sep4 MTD"
    })

monthly = pd.concat([raw_monthly, pd.DataFrame(aug_rows)], ignore_index=True)
monthly = add_metrics(monthly)
monthly.to_csv(ROOT / "data/processed/monthly_volume_2026_jan_aug.csv", index=False)
sep.to_csv(ROOT / "data/processed/sep04_snapshot.csv", index=False)

german = german_curve_summary(monthly)
german.to_csv(ROOT / "data/processed/german_curve_monthly.csv", index=False)
ytd = ytd_summary(monthly)
ytd.to_csv(ROOT / "data/processed/ytd_summary.csv", index=False)

# FBEU adoption snapshot from Sep 4 official daily stats
fbeu = sep.loc[sep.product_code.eq("FBEU")].copy()
fbeu.to_csv(ROOT / "data/processed/fbeu_sep04_snapshot.csv", index=False)

# Figure 1: German curve monthly volume
pivot = monthly[monthly.product_code.isin(["FGBS","FGBM","FGBL"])].pivot(index="month_num", columns="product_code", values="monthly_volume").sort_index()
fig, ax = plt.subplots(figsize=(9,5.2))
for code in ["FGBS","FGBM","FGBL"]:
    ax.plot(pivot.index, pivot[code]/1e6, marker="o", label=code)
ax.set_xticks(range(1,9), ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug"])
ax.set_ylabel("Monthly traded contracts (millions)")
ax.set_title("German government bond futures activity — 2026 Jan–Aug")
ax.legend()
ax.grid(alpha=0.25)
fig.tight_layout(); fig.savefig(ROOT / "figures/01_german_monthly_volume.png", dpi=180); plt.close(fig)

# Figure 2: Monthly ADV
adv = monthly[monthly.product_code.isin(["FGBS","FGBM","FGBL"])].pivot(index="month_num", columns="product_code", values="adv").sort_index()
fig, ax = plt.subplots(figsize=(9,5.2))
for code in ["FGBS","FGBM","FGBL"]:
    ax.plot(adv.index, adv[code]/1e6, marker="o", label=code)
ax.set_xticks(range(1,9), ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug"])
ax.set_ylabel("Average daily volume (millions)")
ax.set_title("Average daily volume — roll months stand out")
ax.legend(); ax.grid(alpha=0.25)
fig.tight_layout(); fig.savefig(ROOT / "figures/02_german_adv.png", dpi=180); plt.close(fig)

# Figure 3: 10Y sovereign benchmark comparison
p10 = monthly[monthly.product_code.isin(["FGBL","FBTP","FOAT"])].pivot(index="month_num", columns="product_code", values="monthly_volume").sort_index()
fig, ax = plt.subplots(figsize=(9,5.2))
for code in ["FGBL","FBTP","FOAT"]:
    ax.plot(p10.index, p10[code]/1e6, marker="o", label=code)
ax.set_xticks(range(1,9), ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug"])
ax.set_ylabel("Monthly traded contracts (millions)")
ax.set_title("Selected 10Y sovereign futures on Eurex")
ax.legend(); ax.grid(alpha=0.25)
fig.tight_layout(); fig.savefig(ROOT / "figures/03_10y_sovereign_comparison.png", dpi=180); plt.close(fig)

# Figure 4: Jan-Aug German curve shares
ys = ytd[ytd.product_code.isin(["FGBS","FGBM","FGBL"])].set_index("product_code")["jan_aug_volume"]
fig, ax = plt.subplots(figsize=(7,4.8))
ax.bar(ys.index, ys.values/1e6)
ax.set_ylabel("Jan–Aug traded contracts (millions)")
ax.set_title("German curve: Jan–Aug 2026 activity")
for i,v in enumerate(ys.values): ax.text(i, v/1e6+2, f"{v/1e6:.1f}m", ha="center")
fig.tight_layout(); fig.savefig(ROOT / "figures/04_german_ytd_volume.png", dpi=180); plt.close(fig)

# Summary metrics markdown-ready CSV
metrics=[]
g = monthly[monthly.product_code.isin(["FGBS","FGBM","FGBL"])]
for code in ["FGBS","FGBM","FGBL"]:
    x=g[g.product_code.eq(code)]
    roll=x[x.roll_month]["monthly_volume"].mean()
    non=x[~x.roll_month]["monthly_volume"].mean()
    metrics.append({"metric":f"{code} roll-month uplift vs non-roll average","value":(roll/non-1)*100,"unit":"%"})
metrics += [
    {"metric":"German curve Jan-Aug total volume","value":g.monthly_volume.sum(),"unit":"contracts"},
    {"metric":"German curve Jan-Aug ADV","value":g.monthly_volume.sum()/169,"unit":"contracts/day"},
]
for code in ["FGBS","FGBM","FGBL"]:
    v=g[g.product_code.eq(code)].monthly_volume.sum()
    metrics.append({"metric":f"{code} share of German Jan-Aug volume","value":v/g.monthly_volume.sum()*100,"unit":"%"})
for code in ["FGBL","FBTP","FOAT"]:
    subset=monthly[monthly.product_code.isin(["FGBL","FBTP","FOAT"])].groupby('product_code').monthly_volume.sum()
    metrics.append({"metric":f"{code} share of selected 10Y sovereign volume","value":subset[code]/subset.sum()*100,"unit":"%"})
pd.DataFrame(metrics).to_csv(ROOT / "data/processed/key_metrics.csv", index=False)

print("Built project outputs successfully")
