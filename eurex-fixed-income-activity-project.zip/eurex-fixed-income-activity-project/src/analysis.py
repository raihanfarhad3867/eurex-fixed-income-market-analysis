from __future__ import annotations
import pandas as pd

GERMAN = ["FGBS", "FGBM", "FGBL"]
TENOR_10Y = ["FGBL", "FBTP", "FOAT"]
ROLL_MONTHS = {3, 6, 9, 12}
MONTH_MAP = {"Jan":1,"Feb":2,"Mar":3,"Apr":4,"May":5,"Jun":6,"Jul":7,"Aug":8,"Sep":9,"Oct":10,"Nov":11,"Dec":12}


def add_metrics(df: pd.DataFrame) -> pd.DataFrame:
    x = df.copy()
    x["month_num"] = x["month"].map(MONTH_MAP)
    x["adv"] = x["monthly_volume"] / x["trading_days"]
    x["roll_month"] = x["month_num"].isin(ROLL_MONTHS)
    x = x.sort_values(["product_code", "month_num"])
    x["mom_change_pct"] = x.groupby("product_code")["monthly_volume"].pct_change() * 100
    return x


def german_curve_summary(df: pd.DataFrame) -> pd.DataFrame:
    x = df[df.product_code.isin(GERMAN)].copy()
    month_total = x.groupby(["year","month","month_num"], as_index=False)["monthly_volume"].sum().rename(columns={"monthly_volume":"german_curve_total"})
    x = x.merge(month_total, on=["year","month","month_num"], how="left")
    x["share_of_german_curve_pct"] = x["monthly_volume"] / x["german_curve_total"] * 100
    return x


def ytd_summary(df: pd.DataFrame) -> pd.DataFrame:
    rows=[]
    for code, g in df.groupby("product_code"):
        rows.append({
            "product_code": code,
            "product_name": g["product_name"].iloc[0],
            "jan_aug_volume": int(g["monthly_volume"].sum()),
            "jan_aug_trading_days": int(g["trading_days"].drop_duplicates().sum()),
            "jan_aug_adv": g["monthly_volume"].sum() / g["trading_days"].drop_duplicates().sum(),
            "peak_month": g.loc[g["monthly_volume"].idxmax(), "month"],
            "peak_month_volume": int(g["monthly_volume"].max()),
        })
    return pd.DataFrame(rows).sort_values("jan_aug_volume", ascending=False)
