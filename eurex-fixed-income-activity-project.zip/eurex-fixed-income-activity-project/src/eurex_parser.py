from __future__ import annotations
import pandas as pd
from pathlib import Path

PRODUCT_CODES = ["FGBS", "FGBM", "FGBL", "FGBX", "FBTP", "FOAT", "FBTS", "FBEU"]

NUMERIC_COLS = {
    5: "daily_volume",
    7: "month_to_date_volume",
    9: "year_to_date_volume",
    11: "avg_daily_volume_month",
    12: "avg_daily_volume_year",
    14: "open_interest_prev_day",
}


def _to_num(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s.astype(str).str.replace(",", "", regex=False).replace("nan", pd.NA), errors="coerce")


def parse_daily_statistics_csv(path: str | Path, codes=PRODUCT_CODES) -> pd.DataFrame:
    """Parse a Eurex Daily Statistics CSV exported from the public statistics file.

    The file contains report metadata above the data body. Product code is column 5
    in Excel terms / zero-based column 4 in pandas raw import.
    """
    raw = pd.read_csv(path, header=None)
    rows = raw[raw[4].astype(str).isin(codes)].copy()
    out = pd.DataFrame({
        "product_name": rows[3].astype(str).values,
        "product_code": rows[4].astype(str).values,
    })
    for idx, name in NUMERIC_COLS.items():
        out[name] = _to_num(rows[idx]).values
    # Date appears in the metadata area (row 6 in Excel-ish view / raw row index 6? search robustly)
    date = None
    for value in raw.iloc[:12, 0].dropna().astype(str):
        try:
            parsed = pd.to_datetime(value, format="%m/%d/%Y", errors="raise")
            date = parsed.date().isoformat()
            break
        except Exception:
            continue
    out.insert(0, "date", date)
    return out.reset_index(drop=True)
