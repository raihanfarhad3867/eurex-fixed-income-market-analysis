# Management memo — Fixed-income futures activity & product opportunity

## Executive message
The German government-bond futures complex remains the activity anchor in this sample. Across Jan–Aug 2026, FGBS/FGBM/FGBL generated about **553.7 million contracts**, or roughly **3.28 million contracts per trading day** in aggregate. FGBL contributed about **39.3%** of this three-product volume, FGBM **31.3%**, and FGBS **29.4%**.

Quarterly expiry months matter. March and June volumes were materially above non-roll-month averages. The uplift was strongest in FGBS, where March/June average monthly volume was about **118% above** the non-roll-month average. FGBM and FGBL showed roughly **61%** and **59%** uplifts. This should not be interpreted as roll activity alone: March 2026 was also a high-volatility month in which Eurex reported a 47% YoY rise in interest-rate-derivatives volume.

Among selected 10-year sovereign futures, FGBL represented about **65.0%** of Jan–Aug volume versus **19.3%** for FBTP and **15.7%** for FOAT. This illustrates the benchmark strength of Bund futures within this selected comparison.

## 4 September snapshot
The official daily report shows:
- FGBS: 1,718,237 contracts traded; 2,643,073 previous-day OI.
- FGBM: 1,891,812; 1,921,811 OI.
- FGBL: 2,026,366; 2,106,126 OI.

Daily volume leadership and open-interest leadership are not the same: FGBL led daily volume among the three, while FGBS had the largest previous-day OI.

## Product opportunity: FBEU as a live adoption case
Euro-EU Bond Futures (FBEU) started trading on 10 September 2025 after market-participant dialogue. Eurex positioned the contract as part of its broader European fixed-income ecosystem and launched it with dedicated liquidity-provider support.

Yet the 4 September 2026 daily statistics show only **13,291 contracts YTD** and **107 contracts of previous-day open interest**, with zero contracts traded that day. This is tiny compared with established sovereign benchmarks. Eurex's 28 August 2026 decision to amend/extend the FBEU liquidity-provider program reinforces that liquidity formation remains an active product-management issue.

## Recommendation
Do **not** jump from these data to "launch another contract." A stronger product-team question is: **what prevents adoption of FBEU, and which intervention would most improve executable liquidity?**

Priority next analyses:
1. Client interviews: identify actual EU-bond hedge workflows and reasons for using cash, swaps, Bund/OAT/BTP proxies or no hedge.
2. Market-maker economics: measure quote obligations, spread/depth, inventory risk and whether the revised LP program changes behavior.
3. Execution comparison: compare FBEU versus proxy hedges in Bund/OAT/BTP on basis risk, margin efficiency and all-in cost.
4. Cash-futures linkage: study the deliverable basket, CTD behavior and secondary-market liquidity of eligible EU bonds.
5. Adoption funnel: monitor active participants, block/TES usage, daily trading frequency, open-interest retention and expiry-to-expiry roll.

The commercial decision should be based on whether FBEU solves a real hedging/execution problem and whether two-sided liquidity can become self-sustaining after incentives are reduced.
