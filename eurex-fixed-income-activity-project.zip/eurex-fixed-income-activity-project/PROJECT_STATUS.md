# Project status

**Status: portfolio-ready analysis v1**

Completed:
- official Jan–Jul 2026 monthly volume dataset
- programmatic parsing of 4 Sep 2026 daily Eurex CSV
- deterministic August reconstruction
- ADV, market-share, MoM and roll-month analysis
- German curve and sovereign benchmark charts
- FBEU product-adoption case
- management memo, methodology, interview concepts and LinkedIn draft
- automated validation tests

Next extension if internal/high-frequency data are available:
- bid/ask spread and depth
- contract-level roll curves
- execution-cost analysis
- client/account-type segmentation
- market-maker quote quality
- cash-futures basis and CTD analysis for FBEU
